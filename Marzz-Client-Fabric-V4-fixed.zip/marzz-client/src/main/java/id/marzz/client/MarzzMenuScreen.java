package id.marzz.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class MarzzMenuScreen extends Screen {
    public MarzzMenuScreen() {
        super(Text.literal("Marzz Client"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y = this.height / 2 - 74;

        addToggle(cx - 105, y, 210, "Storage Tracers", () -> StorageTracerConfig.enabled,
                v -> StorageTracerConfig.enabled = v);

        addToggle(cx - 105, y + 24, 102, "Chest", () -> StorageTracerConfig.chest,
                v -> StorageTracerConfig.chest = v);
        addToggle(cx + 3, y + 24, 102, "Ender Chest", () -> StorageTracerConfig.enderChest,
                v -> StorageTracerConfig.enderChest = v);
        addToggle(cx - 105, y + 48, 102, "Trapped Chest", () -> StorageTracerConfig.trappedChest,
                v -> StorageTracerConfig.trappedChest = v);
        addToggle(cx + 3, y + 48, 102, "Shulker", () -> StorageTracerConfig.shulker,
                v -> StorageTracerConfig.shulker = v);
        addToggle(cx - 105, y + 72, 102, "Spawner", () -> StorageTracerConfig.spawner,
                v -> StorageTracerConfig.spawner = v);
        addToggle(cx + 3, y + 72, 102, "Barrel", () -> StorageTracerConfig.barrel,
                v -> StorageTracerConfig.barrel = v);
        addToggle(cx - 105, y + 96, 102, "Furnace", () -> StorageTracerConfig.furnace,
                v -> StorageTracerConfig.furnace = v);

        addToggle(cx - 105, y + 130, 102, "Chunk Borders", () -> WorldAnalyzerConfig.chunkBorders,
                v -> WorldAnalyzerConfig.chunkBorders = v);
        addToggle(cx + 3, y + 130, 102, "Terrain Notes", () -> WorldAnalyzerConfig.exploredTerrainNotes,
                v -> WorldAnalyzerConfig.exploredTerrainNotes = v);
        addToggle(cx - 105, y + 154, 102, "Coordinates", () -> WorldAnalyzerConfig.showCoordinates,
                v -> WorldAnalyzerConfig.showCoordinates = v);

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(cx + 3, y + 178, 102, 20).build());
    }

    private void addToggle(int x, int y, int width, String name,
                           java.util.function.BooleanSupplier getter,
                           java.util.function.Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(label(name, getter.getAsBoolean()), b -> {
            boolean next = !getter.getAsBoolean();
            setter.accept(next);
            MarzzConfig.save();
            b.setMessage(label(name, next));
        }).dimensions(x, y, width, 20).build());
    }

    private static Text label(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int w = 260;
        int h = 280;
        int left = (width - w) / 2;
        int top = (height - h) / 2;
        context.fill(left, top, left + w, top + h, 0xE9202430);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("MARZZ CLIENT"),
                width / 2, top + 8, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("UTILITY CONFIGURATION"),
                width / 2, top + 21, 0xB9A4FF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Local preferences only — no hidden-block scanning"),
                width / 2, top + h - 12, 0xAABBDD);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}

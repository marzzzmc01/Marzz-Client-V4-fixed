package id.marzz.client;

/**
 * Preferences for non-invasive world analysis.
 * This starter only exposes settings; terrain classification/rendering is a
 * separate implementation step and is restricted to worlds/areas the player
 * is authorized to inspect.
 */
public final class WorldAnalyzerConfig {
    private WorldAnalyzerConfig() {}

    public static boolean chunkBorders = true;
    public static boolean exploredTerrainNotes = true;
    public static boolean showCoordinates = true;
}

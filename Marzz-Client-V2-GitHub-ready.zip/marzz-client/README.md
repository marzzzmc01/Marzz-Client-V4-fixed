# Marzz Client — Fabric starter (V4)

Minecraft Java **1.21.11**, client-side Fabric utility starter. Requires **Java 21**.

## Current implementation

- Opens the Marzz Client settings screen with **Right Shift**.
- Saves local menu preferences to `config/marzz-client.properties`.
- Loads saved preferences on client startup.
- Includes settings for Storage Tracers and World Analyzer, but their tracer rendering and terrain-analysis features are **not implemented yet**.
- Does not scan hidden blocks, manipulate packets, bypass anti-cheat, or discover private bases.

## Build

1. Install a 64-bit JDK 21 and Gradle 9.7.1 or newer compatible with Fabric Loom 1.14.
2. Open this project folder in IntelliJ IDEA and allow Gradle sync, or open a terminal in this folder.
3. If Gradle wrapper scripts are not present yet, generate them once with:
   - Windows: `gradle wrapper --gradle-version 9.7.1`
   - Linux/macOS: `gradle wrapper --gradle-version 9.7.1`
4. Build with `gradle build` (or `gradlew.bat build` on Windows / `./gradlew build` on Linux/macOS after wrapper generation).
5. The distributable mod JAR is created in `build/libs/`. Use the JAR without `-sources` in its filename.

## Compatibility

Versions are configured in `gradle.properties`. Verify compatible Fabric Loader, Fabric API, Yarn mappings, and Loom versions before changing Minecraft versions.

## If build fails

Share the complete Gradle build output and the exact Java version. Do not share passwords, session tokens, or other private credentials.


## Marzz Client 1.1.0 HUD
- Keystrokes overlay (WASD, left and right mouse buttons).
- FPS overlay.
- Player XYZ coordinate overlay.
- HUD toggles are available from the Marzz menu (Right Shift) and saved locally.

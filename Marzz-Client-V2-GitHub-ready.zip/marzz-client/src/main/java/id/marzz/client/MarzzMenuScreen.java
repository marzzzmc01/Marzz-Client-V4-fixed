package id.marzz.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class MarzzMenuScreen extends Screen {
    public MarzzMenuScreen() { super(Text.literal("Marzz Client")); }

    @Override
    protected void init() {
        int cx = width / 2;
        int left = cx - 110;
        int right = cx + 4;
        int y = height / 2 - 88;
        addToggle(left, y, 106, "Keystrokes HUD", () -> MarzzHudConfig.showKeystrokes, v -> MarzzHudConfig.showKeystrokes = v);
        addToggle(right, y, 106, "FPS HUD", () -> MarzzHudConfig.showFps, v -> MarzzHudConfig.showFps = v);
        addToggle(left, y + 24, 220, "Coordinates HUD", () -> MarzzHudConfig.showCoordinates, v -> MarzzHudConfig.showCoordinates = v);
        addToggle(left, y + 58, 106, "Storage Tracers", () -> StorageTracerConfig.enabled, v -> StorageTracerConfig.enabled = v);
        addToggle(right, y + 58, 106, "Chunk Borders", () -> WorldAnalyzerConfig.chunkBorders, v -> WorldAnalyzerConfig.chunkBorders = v);
        addToggle(left, y + 82, 106, "Terrain Notes", () -> WorldAnalyzerConfig.exploredTerrainNotes, v -> WorldAnalyzerConfig.exploredTerrainNotes = v);
        addToggle(right, y + 82, 106, "World Coords", () -> WorldAnalyzerConfig.showCoordinates, v -> WorldAnalyzerConfig.showCoordinates = v);
        addToggle(left, y + 116, 106, "Chest", () -> StorageTracerConfig.chest, v -> StorageTracerConfig.chest = v);
        addToggle(right, y + 116, 106, "Ender Chest", () -> StorageTracerConfig.enderChest, v -> StorageTracerConfig.enderChest = v);
        addToggle(left, y + 140, 106, "Trapped Chest", () -> StorageTracerConfig.trappedChest, v -> StorageTracerConfig.trappedChest = v);
        addToggle(right, y + 140, 106, "Shulker", () -> StorageTracerConfig.shulker, v -> StorageTracerConfig.shulker = v);
        addToggle(left, y + 164, 106, "Spawner", () -> StorageTracerConfig.spawner, v -> StorageTracerConfig.spawner = v);
        addToggle(right, y + 164, 106, "Barrel", () -> StorageTracerConfig.barrel, v -> StorageTracerConfig.barrel = v);
        addToggle(left, y + 188, 106, "Furnace", () -> StorageTracerConfig.furnace, v -> StorageTracerConfig.furnace = v);
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close()).dimensions(right, y + 188, 106, 20).build());
    }

    private void addToggle(int x, int y, int w, String name, java.util.function.BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(label(name, getter.getAsBoolean()), b -> {
            boolean next = !getter.getAsBoolean(); setter.accept(next); MarzzConfig.save(); b.setMessage(label(name, next));
        }).dimensions(x, y, w, 20).build());
    }
    private static Text label(String name, boolean enabled) { return Text.literal(name + ": " + (enabled ? "ON" : "OFF")); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int w = 250, h = 254, left = (width - w) / 2, top = (height - h) / 2;
        context.fill(left, top, left + w, top + h, 0xE91B1428);
        context.fill(left, top, left + w, top + 2, 0xFFB78CFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("MARZZ CLIENT"), width / 2, top + 8, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("PURPLE HUD SETTINGS"), width / 2, top + 21, 0xFFB78CFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }
}
